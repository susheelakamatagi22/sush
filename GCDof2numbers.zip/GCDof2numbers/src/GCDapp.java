import java.util.Scanner;

public class GCDapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("enter a number");
		int m=scan.nextInt();
		int n=scan.nextInt();
		
		int res=GCD.findgcd(m, n);
		System.out.println(res);

	}

}
